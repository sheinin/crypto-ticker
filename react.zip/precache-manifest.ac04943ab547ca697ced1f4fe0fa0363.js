self.__precacheManifest = [
  {
    "revision": "2bf0d8920985614e18fb",
    "url": "/binance/static/css/main.8216c45f.chunk.css"
  },
  {
    "revision": "2bf0d8920985614e18fb",
    "url": "/binance/static/js/main.f4217b02.chunk.js"
  },
  {
    "revision": "6e2e9ec45512ef383e36",
    "url": "/binance/static/js/runtime~main.1b49452d.js"
  },
  {
    "revision": "e74d7f70fa3b45ce5d7f",
    "url": "/binance/static/css/2.423700bd.chunk.css"
  },
  {
    "revision": "e74d7f70fa3b45ce5d7f",
    "url": "/binance/static/js/2.e450d935.chunk.js"
  },
  {
    "revision": "055220281a80c5a6b65d83121b7894ff",
    "url": "/binance/index.html"
  }
];